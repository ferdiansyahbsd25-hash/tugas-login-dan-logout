<?php
session_start();

// Cek apakah admin sudah login
if (!isset($_SESSION["admin_id"])) {
    header("Location: ../auth/login.php");
    exit;
}

$adminName = $_SESSION["admin_name"];
$adminEmail = $_SESSION["admin_email"];
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Heriest Advertising</title>
    <!-- Import Font Poppins -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="dashboard-container">
        <!-- NAVBAR -->
        <nav class="navbar">
            <div class="nav-brand">
                <div class="nav-logo">HA</div>
                <h2>Heriest <span>Advertising</span></h2>
            </div>
            <a href="../auth/logout.php" class="btn-logout">Keluar</a>
        </nav>
        
        <!-- CONTENT -->
        <main class="dashboard-content">
            <div class="dashboard-card">
                <div class="welcome-header">
                    <h1>Selamat Datang, <span class="highlight"><?= htmlspecialchars($adminName) ?>!</span></h1>
                    <p>Anda berhasil mengakses sistem manajemen pusat <b>Heriest Advertising</b>.</p>
                </div>
                
                <div class="info-box">
                    <div class="info-item">
                        <span class="info-label">Status Akses:</span>
                        <span class="info-value text-green">Administrator Aktif</span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Email Terdaftar:</span>
                        <span class="info-value"><?= htmlspecialchars($adminEmail) ?></span>
                    </div>
                </div>
            </div>
        </main>
    </div>
</body>
</html>